/*********************************************************************************
 * **                                                                           **
 * ** ALTERA CONFIDENTIAL                                                       **
 * **                                                                           **
 * ** Copyright 2024 Altera/ALTERA Corporation All Rights Reserved.             **
 * **                                                                           **
 * ** The source code contained or described herein and all documents related   **
 * ** to the source code ("Material") are owned by Altera Corporation or its    **
 * ** suppliers or licensors.  Title to the Material remains with Altera        **
 * ** Corporation or its suppliers and licensors.  The Material contains trade  **
 * ** secrets and proprietary and confidential information of Altera or its     **
 * ** suppliers and licensors.  The Material is protected by worldwide          **
 * ** copyright and trade secret laws and treaty provisions.  No part of the    **
 * ** Material may be used, copied, reproduced, modified, published, uploaded,  **
 * ** posted, transmitted, distributed, or disclosed in any way without Altera's**
 * ** prior express written permission.                                         **
 * **                                                                           **
 * ** No license under any patent, copyright, trade secret or other             **
 * ** intelectual property right is granted to or conferred upon you by         **
 * ** disclosure or delivery of the Materials, either expressly, by             **
 * ** implication, inducement, estoppel or otherwise.  Any license under such   **
 * ** intelectual property rights must be express and approved by Altera in     **
 * ** writing.                                                                  **
 * **                                                                           **
 * ** Application - PTP Bridge Application v1.0                                 **
 * ** Author - Krishna Kumar S R                                                **
 * ******************************************************************************/

#include <errno.h>
#include <getopt.h>
#include <inttypes.h>
#include <stdio.h>
#include <stddef.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/timeb.h>
#include <time.h>
#include <string.h>
#include <getopt.h>
#include <arpa/inet.h>
#include "ptpbridgeRegisterMap.h"
#include "ptpbridgeRegisterInterface.h"

#define DEFAULT_WIDTH 4
#define PROGRAM_NAME "ptpBridge"
#define PTP_BRIDGE_MAP_SIZE	sizeof(ptpBridge_t)
#define min(a, b) ((a) < (b) ? (a) : (b))

typedef enum operation {
	PTP_BRIDGE_OPR_DUMP,
	PTP_BRIDGE_OPR_SET_KEY,
	PTP_BRIDGE_OPR_SHOW_KEY,
	PTP_BRIDGE_OPR_REMOVE_KEY,
	PTP_BRIDGE_OPR_FLUSH_ALL_KEY,
	PTP_BRIDGE_OPR_FLUSH_ALL_COUNTERS,
	PTP_BRIDGE_OPR_REGISTER_READ,
	PTP_BRIDGE_OPR_REGISTER_WRITE,
	PTP_BRIDGE_OPR_MAX,
} operation_t;

static struct option long_options[] = {
    {"help",    	no_argument,       0, 'h'},
    {"device",      required_argument, 0, 'd'},
    {"dump", 		no_argument,	   0, 'x'},
    {"set-key", 	no_argument,	   0, 's'},
    {"remove-key", 	no_argument,       0, 'r'},
    {"register-rw", no_argument,       0, 'w'},
    {"key-index", 	required_argument, 0, 0},
    {"dest-mac",	required_argument, 0, 0},
    {"src-mac",		required_argument, 0, 0},
    {"dest-ip",     required_argument, 0, 0},
    {"src-ip",      required_argument, 0, 0},
    {"dest-port",   required_argument, 0, 0},
    {"src-port",    required_argument, 0, 0},
    {"vlanb",     	required_argument, 0, 0},
    {"vlana",     	required_argument, 0, 0},
    {"ethtype",     required_argument, 0, 0},
    {"protocol",    required_argument, 0, 0},
    {"message",     required_argument, 0, 0},
    {"flag",     	required_argument, 0, 0},
    {"result",      required_argument, 0, 0},
    {"port",        required_argument, 0, 0},
    {"register-offset", required_argument, 0, 0},
    {"register-value", 	required_argument, 0, 0},
    {"length", 		required_argument, 0, 0},
    {"show-key", 	no_argument,       0, 0},
    {"flush-all-keys", 	no_argument,       0, 0},
    {"flush-all-counters", 	no_argument,       0, 0},
	{"mask",        required_argument, 0, 0},
    {0, 0, 0, 0} // End of array need to be filled with zeros
};


static void usage(int exit_status) {
    fprintf(exit_status == EXIT_SUCCESS ? stdout : stderr,
        "Usage: %s [--device] [/dev/uioX] [Options]\n"
        "\n"
        "Functions:\n"
        "  Configure PTP Bridge IP\n"
        "  Read Write registers in the PTP Bridge IP\n"
        "  Set/Remove TCAM rules in the PTP Bridge IP\n"
	"  Dump the PTP Bridge IP registers"
	"\n"
	"Options:\n"
	"	help			\t Print this help contents\n"
	"	device			\t uio device name\n"
	"	dump			\t Dump all register contents\n"
	"	set-key			\t Set Key. Requires Key fields to be provided\n"
	"	remove-key		\t Remove Key using key-index\n"
	"	flush-all-keys		\t Flush all Key entries from the system\n"
	"	flush-all-counters	\t Flush all debug counters value to 0\n"
	"	show-key		\t Search for Keys fulfilling a search criteria for a port\n"
	"	register-rw		\t Do a direct register read write\n"
	"	key-index		\t Key index to work on\n"
	"	dest-mac		\t Key - Destination Mac\n"
	"	src-mac			\t Key - Source Mac\n"
	"	dest-ip			\t Key - Destination IP Address\n"
	"	src-ip			\t Key - Source IP address\n"
	"	dest-port		\t Key - Destination L4 port\n"
	"	src-port		\t Key - Source L4 port\n"
	"	vlanb			\t Key - VALNB\n"
	"	vlana			\t Key - VLANA\n"
	"	ethtype			\t Key - Ethernet type\n"
	"	protocol		\t Key - IP Protocol type\n"
	"	message			\t Key - IP Message type\n"
	"	flag			\t Key - Flag field\n"
	"	result			\t Result\n"
	"	port			\t Ethernet port index eth1-0 eth2-1 etc\n"
	"	register-offset		\t Register offset to read/write to.\n"
	"	register-value		\t Register value to write. Can be comma seperated to write multiple values.\n"
	"	length 			\t Number of registers to read\n"
	"	mask 			\t Set Mask properties for fields manually\n"
	,
	    PROGRAM_NAME);
}

#define UIO_PATH "/sys/class/uio"
#define NAME_FILE "name"
#define SYSFS_PROGRAM_NAME "ptp_bridge"
#define MAX_NAME_LEN 1024
#define MAX_DEVICE_PATH_LEN 12

/**
 * @brief Finds the PTP bridge device.
 * 
 * This function searches for the PTP bridge device in the system.
 * It returns the device if found, otherwise returns NULL.
 * 
 * @param device_name The name of the device to search for.
 * 
 * @return The PTP bridge device if found, otherwise NULL.
 */
int findPTPBridgeDevice(const char* device_name, char *device) {
    DIR *dir;
    struct dirent *entry;
    char name_path[MAX_NAME_LEN];
    char found_name[MAX_NAME_LEN];
    FILE *name_file;
	bool found = false;

    // Open the UIO directory
    dir = opendir(UIO_PATH);
    if (!dir) {
        perror("Not able to open sysfs directory");
        return FAILURE;
    }

    // Iterate over all entries in the UIO directory
    while ((entry = readdir(dir)) != NULL) {
        // Skip "." and ".." entries
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
            continue;
        }

        // Construct the full path to the 'name' file
        snprintf(name_path, sizeof(name_path), "%s/%s/%s", UIO_PATH, entry->d_name, NAME_FILE);

        // Open the 'name' file
        name_file = fopen(name_path, "r");
        if (!name_file) {
            continue; // If we can't open the file, skip this entry
        }

        // Read the device name from the file
        if (fgets(found_name, sizeof(found_name), name_file) != NULL) {
            // Remove newline character if present
            found_name[strcspn(found_name, "\n")] = 0;

            // Check if the found name matches the desired device name
            if (strncmp(found_name, device_name, strlen(device_name)) == 0) {
                // Construct the device path to the device
				memset(device, 0, MAX_DEVICE_PATH_LEN);
				snprintf(device, MAX_DEVICE_PATH_LEN, "/dev/%s", entry->d_name);
                fclose(name_file);
				found = true;
                break;
            }
        }
        fclose(name_file);
    }

    closedir(dir);
	if (found)
    	return SUCCESS;
	else
		return FAILURE;
}

/**
 * @brief Parses a list of numbers from a given string
 * 
 * Parses a list of numbers from a given string.
 *
 * @param str The string containing the numbers.
 * @param count The number of numbers parsed.
 * 
 * @return An array of integers representing the parsed numbers.
 */
uint32 *parse_number_list(const char *str, uint32 *count) {
	uint32 *array = NULL;
	uint32 capacity = 10;
	*count = 0;

	// Allocate initial memory for the array
	array = malloc(capacity * sizeof(int));
	if (!array) {
		perror("malloc");
		return NULL;
	}

	// Duplicate the string for tokenization
	char *str_copy = strdup(str);
	if (!str_copy) {
		perror("strdup");
		free(array);
		return NULL;
	}

	// Tokenize the string and parse the numbers
	char *token = strtok(str_copy, ",");
	while (token) {
		if (*count >= capacity) {
			// Increase the capacity of the array
			capacity *= 2;
			uint32 *new_array = realloc(array, capacity * sizeof(int));
			if (!new_array) {
				perror("realloc");
				free(array);
				free(str_copy);
				return NULL;
			}
			array = new_array;
		}

		// Convert token to integer and add to the array
		//array[*count] = atoi(token);
		array[*count] = strtoul(token, NULL, 0);
		(*count)++;

		// Get the next token
		token = strtok(NULL, ",");
	}

	free(str_copy); // Free the duplicated string
	return array;   // Return the array of numbers
}
#define MAX_ETH_DEVICE_NAME_LEN		8
#define MAX_ETH_DEVICES_SUPPORTED	4
int isPortNumValid(uint32 port)
{
	char ethDevice[MAX_ETH_DEVICE_NAME_LEN];
	memset(ethDevice, 0, MAX_ETH_DEVICE_NAME_LEN);
	snprintf(ethDevice, MAX_ETH_DEVICE_NAME_LEN, "eth%d", (port+1)); //eth0 is not FTile device on our board
	return (isEthernetPortValid(ethDevice));
}

int main(int argc, char *argv[]) {
	int fd, exitResult=EXIT_SUCCESS;
	char devicePath[MAX_DEVICE_PATH_LEN];
	char *fpath = NULL;
	ptpBridge_t *ptr = NULL;
	int map_size, port=MAX_NUM_PORTS_SUPPORTED;
	int opt;
	int option_index = 0;
	uint32 registerAddress = 0x0;
	uint32 *data = 0;
	uint32 count = 0;
	uint32 keyIndex = MAX_TCAM_KEYS_SUPPORTED;
	ptpBridgeKey_t userKey;
	ptpBridgeMask_t userMask;
	uint32 result=0;
	memset(&userKey, 0, sizeof(userKey));
	memset(&userMask, 0 ,sizeof(userMask));
	operation_t opr = PTP_BRIDGE_OPR_DUMP;
	int length = 0;
	uint32 prevcmd = 0;

	// Loop through and process the options
	while ((opt = getopt_long(argc, argv, "hd:xsr", long_options, &option_index)) != -1) {
		if (opt == '?') {
			printf("Invalid option. \n");
			usage(EXIT_SUCCESS);
			exitResult = EXIT_SUCCESS;
			goto cleanup;
		}

		switch (option_index) {
			case 0: //help
				usage(EXIT_SUCCESS);  
				exitResult = EXIT_SUCCESS;
				goto cleanup;
			case 1: //device
				fpath = optarg; break;
			case 2: //dump
				opr = PTP_BRIDGE_OPR_DUMP; break;
			case 3: //set-key
				opr = PTP_BRIDGE_OPR_SET_KEY; break;
			case 4: //remove-key
				opr = PTP_BRIDGE_OPR_REMOVE_KEY; break;
			case 5:  //register-rw
				opr = PTP_BRIDGE_OPR_REGISTER_READ; //by default it is set to read 
				break;
			case 6: //key Index
				keyIndex = strtoul(optarg, NULL, 0);
				if (keyIndex >= MAX_TCAM_KEYS_SUPPORTED) exit(EXIT_FAILURE);
				break;
			case 7: //dest-mac
				if (!validate_mac(&(userKey.key.dst_mac),optarg)) {
					exitResult = EXIT_FAILURE;
					goto cleanup;
				}
				memset(&(userMask.key.dst_mac), 0xFF, sizeof(mac_address));
				break;
			case 8: //src-mac
				if (!validate_mac(&(userKey.key.src_mac),optarg)) {
					exitResult = EXIT_FAILURE;
					goto cleanup;
				}
				memset(&(userMask.key.src_mac), 0xFF, sizeof(mac_address));
				break;
			case 9: //dest-ip
				if (settcamRegisterPTPBridgeKeyDestIPAddress(&userKey, &userMask, optarg) != SUCCESS) {
					exitResult = EXIT_FAILURE;
					goto cleanup;
				}
				break;
			case 10: //src-ip 
				if (settcamRegisterPTPBridgeKeySrcIPAddress(&userKey, &userMask, optarg) != SUCCESS) {
					exitResult = EXIT_FAILURE;
					goto cleanup;
				}
				break;
			case 11://dest-port
				if (settcamRegisterPTPBridgeKeyDestL4Port(&userKey, &userMask, strtoul(optarg, NULL, 0)) != SUCCESS) {
					exitResult = EXIT_FAILURE;
					goto cleanup;
				}
				break;
			case 12: //src-port
				if (settcamRegisterPTPBridgeKeySrcL4Port(&userKey, &userMask, strtoul(optarg, NULL, 0)) != SUCCESS) {
					exitResult = EXIT_FAILURE;
					goto cleanup;
				}
				break;
			case 13: //vlanb 
				if (settcamRegisterPTPBridgeKeyVLANB(&userKey, &userMask, strtoul(optarg, NULL, 0)) != SUCCESS) {
					exitResult = EXIT_FAILURE;
					goto cleanup;
				}
				break;
			case 14: //vlana 
				if (settcamRegisterPTPBridgeKeyVLANA(&userKey, &userMask, strtoul(optarg, NULL, 0)) != SUCCESS) {
					exitResult = EXIT_FAILURE;
					goto cleanup;
				}
				break;
			case 15: //ethtype
				if (settcamRegisterPTPBridgeKeyEthType(&userKey, &userMask, strtoul(optarg, NULL, 0)) != SUCCESS) {
					exitResult = EXIT_FAILURE;
					goto cleanup;
				}
				break;
			case 16: //protocol
				if (settcamRegisterPTPBridgeKeyIPProtocol(&userKey, &userMask, strtoul(optarg, NULL, 0)) != SUCCESS) {
					exitResult = EXIT_FAILURE;
					goto cleanup;
				}
				break;
			case 17: //message
				if (settcamRegisterPTPBridgeKeyMessageType(&userKey, &userMask, strtoul(optarg, NULL, 0)) != SUCCESS) {
					exitResult = EXIT_FAILURE;
					goto cleanup;
				}
				break;
			case 18: //flag  
				if (settcamRegisterPTPBridgeKeyFlagField(&userKey, &userMask, strtoul(optarg, NULL, 0)) != SUCCESS) {
					exitResult = EXIT_FAILURE;
					goto cleanup;
				}
				break;
			case 19: //result
				result = strtoul(optarg, NULL, 0);
				break;
			case 20: //port
				if (strncmp(optarg,"eth1",strlen("eth1")) == 0) {
					port = 0;
				} else if (strncmp(optarg,"eth2",strlen("eth2")) == 0) {
					port = 1;
				} else { 
					port = strtoull(optarg, NULL, 0);
				}
				if (isPortNumValid(port) == FAILURE) {
					printf("Port value not valid - %d\n", port);
					usage(EXIT_FAILURE);
					exitResult = EXIT_FAILURE;
					goto cleanup;
				}
				if (port >= MAX_NUM_PORTS_SUPPORTED) {
					printf("Port value not valid%d\n", port);
					usage(EXIT_FAILURE);
					exitResult = EXIT_FAILURE;
					goto cleanup;
				}
				break;
			case 21: //register-offset
				registerAddress = strtoul(optarg, NULL, 0);
				break;
			case 22: //register-value
				 //data = strtoul(optarg, NULL, 0);
				data = parse_number_list(optarg, &count);
				if (data == NULL) {
					printf("Comma seperated 32bit register values required\n");
					usage(EXIT_FAILURE);
					exitResult = EXIT_FAILURE;
					goto cleanup;
				}
				opr = PTP_BRIDGE_OPR_REGISTER_WRITE;
				break;
			case 23: //length
				length = strtoul(optarg, NULL, 0);
				break;
			case 24: //show-key
				opr = PTP_BRIDGE_OPR_SHOW_KEY; break;
			case 25: //flush-all-keys
				opr = PTP_BRIDGE_OPR_FLUSH_ALL_KEY; break;
			case 26: //flush-all-counters
				opr = PTP_BRIDGE_OPR_FLUSH_ALL_COUNTERS; break;
			case 27: //mask
				if ((prevcmd <= 6) || (prevcmd >=19 && prevcmd <= 27)) {
					printf("Mask property cannot be set for this option. Masks can be set only for TCAM register fields\n");
					exitResult = EXIT_FAILURE;
					goto cleanup;
				}
				//For mask we need to get the mask details from CLI and set it in the mask
				switch (prevcmd) {
					case 7: //dest-mac
						if (!validate_mac(&(userMask.key.dst_mac),optarg)) {
							exitResult = EXIT_FAILURE;
							goto cleanup;
						}
						break;
					case 8: //src-mac
						if (!validate_mac(&(userMask.key.src_mac),optarg)) {
							exitResult = EXIT_FAILURE;
							goto cleanup;
						}
						break;
					case 9: //dest-ip
						if (settcamRegisterPTPBridgeMaskDestIPAddress(&userMask, optarg) != SUCCESS) {
							exitResult = EXIT_FAILURE;
							goto cleanup;
						}
						break;
					case 10: //src-ip
						if (settcamRegisterPTPBridgeMaskSrcIPAddress(&userMask, optarg) != SUCCESS) {
							exitResult = EXIT_FAILURE;
							goto cleanup;
						}
						break;
					case 11: //dest-port
						if (settcamRegisterPTPBridgeMaskDestL4Port(&userMask, strtoul(optarg, NULL, 0)) != SUCCESS) {
							exitResult = EXIT_FAILURE;
							goto cleanup;
						}
						break;
					case 12: //src-port
						if (settcamRegisterPTPBridgeMaskSrcL4Port(&userMask, strtoul(optarg, NULL, 0)) != SUCCESS) {
							exitResult = EXIT_FAILURE;
							goto cleanup;
						}
						break;
					case 13: //vlanb 
						if (settcamRegisterPTPBridgeMaskVLANB(&userMask, strtoul(optarg, NULL, 0)) != SUCCESS) {
							exitResult = EXIT_FAILURE;
							goto cleanup;
						}
						break;
					case 14: //vlana 
						if (settcamRegisterPTPBridgeMaskVLANA(&userMask, strtoul(optarg, NULL, 0)) != SUCCESS) {
							exitResult = EXIT_FAILURE;
							goto cleanup;
						}
						break;
					case 15: //ethtype
						if (settcamRegisterPTPBridgeMaskEthType(&userMask, strtoul(optarg, NULL, 0)) != SUCCESS) {
							exitResult = EXIT_FAILURE;
							goto cleanup;
						}
						break;
					case 16: //protocol
						if (settcamRegisterPTPBridgeMaskIPProtocol(&userMask, strtoul(optarg, NULL, 0)) != SUCCESS) {
							exitResult = EXIT_FAILURE;
							goto cleanup;
						}
						break;
					case 17: //message
						if (settcamRegisterPTPBridgeMaskMessageType(&userMask, strtoul(optarg, NULL, 0)) != SUCCESS) {
							exitResult = EXIT_FAILURE;
							goto cleanup;
						}
						break;
					case 18: //flag  
						if (settcamRegisterPTPBridgeMaskFlagField(&userMask, strtoul(optarg, NULL, 0)) != SUCCESS) {
							exitResult = EXIT_FAILURE;
							goto cleanup;
						}
						break;
					default:
						printf("Mask property cannot be set for this option. Masks can be set only for TCAM register fields\n");
						usage(EXIT_FAILURE);
						exitResult = EXIT_FAILURE;
						goto cleanup;
						break;
				}
				break;
			default: 
				printf("Wrong option: %d\n", option_index);
				usage(EXIT_FAILURE);
				exitResult = EXIT_FAILURE;
				goto cleanup;
				break;
		}
		prevcmd = option_index;
	}

	map_size = PTP_BRIDGE_MAP_SIZE;

	if (fpath == NULL) {
		if (findPTPBridgeDevice(SYSFS_PROGRAM_NAME, devicePath) == SUCCESS) {
			fprintf(stdout, "UIO device file found. Using %s\n", devicePath);
			fpath = devicePath;
		} else {
			perror(PROGRAM_NAME);
			fprintf(stderr, "No UIO device specified\n");
			exitResult = EXIT_FAILURE;
			goto cleanup;
		}
	}

	fd = open(fpath, O_RDWR|O_SYNC);
	if (fd < 1) {
		perror(PROGRAM_NAME);
		fprintf(stderr, "Couldn't open UIO device file: %s\n", fpath);
		exitResult = EXIT_FAILURE;
		goto cleanup;
	}
	ptr = mmap(NULL, map_size, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
	if (ptr == MAP_FAILED) {
		perror("mmap");
		fprintf(stderr, "Couldn't mmap.\n");
		exitResult = EXIT_FAILURE;
		goto cleanup;
	} else {

#ifdef DEBUG
		printf("Map of Size %d 0x%X done. Size - PTP Bridge - %ld TCAM: %ld\n", map_size, map_size,
				sizeof(ptpBridge_t), sizeof(tcamRegisterSet_t));
		printf("Offset of ingressArbiter[0]: 0x%lX\n", offsetof(ptpBridge_t, ingressArbiter[0]));
		printf("Offset of ingressArbiter[1]: 0x%lX\n", offsetof(ptpBridge_t, ingressArbiter[1]));
		printf("Offset of egressRXDemux[0]: 0x%lX\n", offsetof(ptpBridge_t, egressRXDemux[0]));
		printf("Offset of egressRXDemux[1]: 0x%lX\n", offsetof(ptpBridge_t, egressRXDemux[1]));
		printf("Offset of ingressRXWidthAdapter[0]: 0x%lX\n", offsetof(ptpBridge_t, ingressRXWidthAdapter[0]));
		printf("Offset of ingressRXWidthAdapter[1]: 0x%lX\n", offsetof(ptpBridge_t, ingressRXWidthAdapter[1]));
		printf("Offset of tcam[0]: 0x%lX\n", offsetof(ptpBridge_t, tcam[0]));
		printf("Offset of tcam[1]: 0x%lX\n", offsetof(ptpBridge_t, tcam[1]));
		printf("Offset of egressRXWidthAdapter[0]: 0x%lX\n", offsetof(ptpBridge_t, egressRXWidthAdapter[0]));
		printf("Offset of egressRXWidthAdapter[1]: 0x%lX\n", offsetof(ptpBridge_t, egressRXWidthAdapter[1]));
#ifdef DEBUG_REG_SUPPORT
		printf("Offset of txdebug[0]: 0x%lX\n", offsetof(ptpBridge_t, txDebug[0]));
		printf("Offset of txdebug[1]: 0x%lX\n", offsetof(ptpBridge_t, txDebug[1]));
		printf("Offset of rxdebug[0]: 0x%lX\n", offsetof(ptpBridge_t, rxDebug[0]));
		printf("Offset of rxdebug[1]: 0x%lX\n", offsetof(ptpBridge_t, rxDebug[1]));
#endif

		printf("Offset of version: 0x%lX\n", offsetof(tcamRegisterSet_t, version));
		printf("Offset of scratch_reg: 0x%lX\n", offsetof(tcamRegisterSet_t, scratch_reg));
		printf("Offset of feature_list: 0x%lX\n", offsetof(tcamRegisterSet_t, feature_list));
		printf("Offset of attr[0]: 0x%lX\n", offsetof(tcamRegisterSet_t, attr));
		printf("Offset of general_control: 0x%lX\n", offsetof(tcamRegisterSet_t, general_control));
		printf("Offset of mgmt_control: 0x%lX\n", offsetof(tcamRegisterSet_t, mgmt_control));
		printf("Offset of entry: 0x%lX\n", offsetof(tcamRegisterSet_t, entry));
		printf("Offset of warning: 0x%lX\n", offsetof(tcamRegisterSet_t, warning));
		printf("Offset of fatal_error: 0x%lX\n", offsetof(tcamRegisterSet_t, fatal_error));
		printf("Offset of monitor: 0x%lX\n", offsetof(tcamRegisterSet_t, monitor));
		printf("Offset of key: 0x%lX\n", offsetof(tcamRegisterSet_t, key));
		printf("Offset of result: 0x%lX\n", offsetof(tcamRegisterSet_t, result));
		printf("Offset of match: 0x%lX\n", offsetof(tcamRegisterSet_t, match));
		printf("Offset of mask: 0x%lX\n", offsetof(tcamRegisterSet_t, mask));
#endif
	}

	switch (opr) {
		case PTP_BRIDGE_OPR_REGISTER_WRITE:
			uint32 *regptr = ((uint32*)((uint8*)ptr + registerAddress));
			int index = 0;
			while (index < count) {
				*regptr = data[index];
				regptr++;
				index ++;
			}
			break;
		case PTP_BRIDGE_OPR_REGISTER_READ:
			if (length == 0) {
				printf("Offset: 0x%X \t%08x\n", (registerAddress), *((uint32*)((uint8*)ptr + registerAddress)));
			} else {
				int rowsize = 16;
				int i, l, linelen, remaining;
				uint32 li = (registerAddress);
				uint32 *addr = ((uint32*)((uint8*)ptr + registerAddress));
				uint32 readVal = 0;
				remaining = length;
				for (i = 0; i < length; i += rowsize) {
					printf("0x%08X\t", li);
					linelen = min(remaining, rowsize);
					remaining -= rowsize;
					for (l = 0; l < linelen/4; l++) {
						readVal = *addr;
						printf("%02X %02X %02X %02X ", ((readVal>>0)&0xFF), ((readVal>>8)&0xFF), ((readVal>>16)&0xFF), ((readVal>>24)&0xFF));
						addr++;
					}

					li += rowsize;
					printf("\n");
					sleep(0);
				}
			}
			break;
		case PTP_BRIDGE_OPR_DUMP:
			dumpPTPBridgeDetails(ptr, port);
			break;
		case PTP_BRIDGE_OPR_SHOW_KEY:
			if (port >= MAX_NUM_PORTS_SUPPORTED) {
				printf("For showing Keys, port is a required fields.%d \n", port);
				usage(EXIT_FAILURE);
				break;
			}
			printf("Copying Search Keyfields: Port: %d - ", port);
			fflush(stdout);
			memcpy32(ptr->tcam[port].key.keys, userKey.keys, sizeof(ptpBridgeKey_t)/4);
			printf("Success\n");

			printf("Setting Mgmt Cntrl Register: ");
			if (SUCCESS != (exitResult = tcamMgmtControlSetOpType(&(ptr->tcam[port]), MGMT_CONTROL_OP_TYPE_SEARCH_ENTRY))) {
				printf("Error setting MgmtControl register with opcode MGMT_CONTROL_OP_TYPE_DELETE_ENTRY_USING_ENTRYID. Exiting...\n");
				break;
			}
			printf("Success\n");
			printf("Wait till operation is done: ");
			tcamMgmtControlWaitTillBusyDone(&(ptr->tcam[port]));
			if (SUCCESS == tcamMgmtControlOperationResult(&(ptr->tcam[port]))) {
				printf("Key Search successful...\n");
			} else {
				printf("Key search not successful...\n");
				break;
			}
			dumptcamRegisterPTPBridgeKeyMultiple(&(ptr->tcam[port].key));
			printf("\t\tResult: 0x%X\n",ptr->tcam[port].result[0]);
			printf("\t\tEntry: 0x%X\n",ptr->tcam[port].entry);
			dumptcamRegisterPTPBridgeArray(ptr->tcam[port].mask.masks, sizeof(ptpBridgeMask_t)/4, "Mask");
			break;
		case PTP_BRIDGE_OPR_SET_KEY: 
			if (port >= MAX_NUM_PORTS_SUPPORTED || keyIndex >= MAX_TCAM_KEYS_SUPPORTED) {
				printf("For setting Keys, port and key-index are required fields.\n");
				usage(EXIT_FAILURE);
				break;
			}
			printf("Setting Entry: ");
			if (SUCCESS != (exitResult = tcamSetEntry(&(ptr->tcam[port]), keyIndex))) {
				printf("Error setting Entry. Exiting...\n");
				break;	
			}
			printf("Success\n");
			printf("Copying Keyfields: Port: %d Key index: %d ", port, keyIndex);
			fflush(stdout);
			memcpy32(ptr->tcam[port].key.keys, userKey.keys, sizeof(ptpBridgeKey_t)/4);
			printf("Success\n");

			printf("Setting Result Register: %d. ", result);
			if (SUCCESS != (exitResult = settcamRegisterResult(&(ptr->tcam[port]), result))) {
				printf("Error setting Result field. Exiting...\n");
				break;
			}
			printf("Success\n");
			printf("Setting Mask Register: ");
			memcpy32(ptr->tcam[port].mask.masks, userMask.masks, sizeof(ptpBridgeMask_t)/4);
			printf("Success\n");
#ifdef DEBUG
			printf("Dump TCAM registers: \n");
			dumptcamRegisterSetMultiple(ptr->tcam, port);
#endif
			printf("Setting Mgmt Cntrl Register: ");
			if (SUCCESS != (exitResult = tcamMgmtControlSetOpType(&(ptr->tcam[port]), MGMT_CONTROL_OP_TYPE_INSERT_ENTRY))) {
				printf("Error setting MgmtControl register with opcode MGMT_CONTROL_OP_TYPE_INSERT_ENTRY. Exiting...\n");
				break;
			}
			printf("Success\n");
			printf("Wait till operation is done: ");
			tcamMgmtControlWaitTillBusyDone(&(ptr->tcam[port]));
			if (SUCCESS == tcamMgmtControlOperationResult(&(ptr->tcam[port]))) {
				printf("Key Insertion successful...\n");
			} else {
				printf("Key Insertion not successful...\n");
			}
			break;
		case PTP_BRIDGE_OPR_FLUSH_ALL_KEY:
			if (port >= MAX_NUM_PORTS_SUPPORTED) {
				printf("For flushing all keys, port number is required field.\n");
				usage(EXIT_FAILURE);
				break;
			}
			if (SUCCESS != (exitResult = tcamMgmtControlSetOpType(&(ptr->tcam[port]), MGMT_CONTROL_OP_TYPE_FLUSH))) {
				printf("Error setting MgmtControl register with opcode MGMT_CONTROL_OP_TYPE_FLUSH. Exiting...\n");
				break;
			}
			tcamMgmtControlWaitTillBusyDone(&(ptr->tcam[port]));
			if (SUCCESS == tcamMgmtControlOperationResult(&(ptr->tcam[port]))) {
				printf("Key Flush successful...\n");
			} else {
				printf("Key Flush not successful...\n");
			}
			break;
		case PTP_BRIDGE_OPR_FLUSH_ALL_COUNTERS:
			if (port >= MAX_NUM_PORTS_SUPPORTED) {
				printf("For flushing all counters, port number is required field.\n");
				usage(EXIT_FAILURE);
				break;
			}
#ifdef DEBUG_REG_SUPPORT
			if (SUCCESS == (exitResult = ptpBridgeFlushAllTxCounters(&(ptr->txDebug[port])))) {
				printf("TX debug counters flush successful...\n");
			} else {
				printf("TX debug counters flush unsuccessful...\n");
			}
			if (SUCCESS == (exitResult = ptpBridgeFlushAllRxCounters(&(ptr->rxDebug[port])))) {
				printf("RX debug counters flush successful...\n");
			} else {
				printf("RX debug counters flush unsuccessful...\n");
			}
#endif
			break;
		case PTP_BRIDGE_OPR_REMOVE_KEY: 
			if (port >= MAX_NUM_PORTS_SUPPORTED || keyIndex >= MAX_TCAM_KEYS_SUPPORTED) {
				printf("For removing key, port and key-index are required fields.\n");
				usage(EXIT_FAILURE);
				break;
			}
			if (SUCCESS != (exitResult = tcamSetEntry(&(ptr->tcam[port]), keyIndex))) {
				printf("Error setting Entry. Exiting...\n");
				break;	
			}
			if (SUCCESS != (exitResult = tcamMgmtControlSetOpType(&(ptr->tcam[port]), MGMT_CONTROL_OP_TYPE_DELETE_ENTRY_USING_ENTRYID))) {
				printf("Error setting MgmtControl register with opcode MGMT_CONTROL_OP_TYPE_DELETE_ENTRY_USING_ENTRYID. Exiting...\n");
				break;
			}
			tcamMgmtControlWaitTillBusyDone(&(ptr->tcam[port]));
			if (SUCCESS == tcamMgmtControlOperationResult(&(ptr->tcam[port]))) {
				printf("Key Removal successful...\n");
			} else {
				printf("Key Removal not successful...\n");
			}
			break;
		default:
			printf("No Operation specified. Please specify the operation that needs to be performed.\n");
			usage(EXIT_FAILURE);
			break;
	}

	/* clean up */
	munmap(ptr, map_size);
	close(fd);
cleanup:
	if (data != NULL)
		free (data);

	return exitResult;
}
