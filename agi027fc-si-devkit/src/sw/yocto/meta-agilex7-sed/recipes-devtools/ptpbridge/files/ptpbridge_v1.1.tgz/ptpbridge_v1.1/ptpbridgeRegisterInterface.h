/*********************************************************************************
 * **                                                                           **
 * ** ALTERA CONFIDENTIAL                                                       **
 * **                                                                           **
 * ** Copyright 2024 Altera/ALTERA Corporation All Rights Reserved.             **
 * **                                                                           **
 * ** The source code contained or described herein and all documents related   **
 * ** to the source code ("Material") are owned by Altera Corporation or its    **
 * ** suppliers or licensors.  Title to the Material remains with Altera        **
 * ** Corporation or its suppliers and licensors.  The Material contains trade  **
 * ** secrets and proprietary and confidential information of Altera or its     **
 * ** suppliers and licensors.  The Material is protected by worldwide          **
 * ** copyright and trade secret laws and treaty provisions.  No part of the    **
 * ** Material may be used, copied, reproduced, modified, published, uploaded,  **
 * ** posted, transmitted, distributed, or disclosed in any way without Altera's**
 * ** prior express written permission.                                         **
 * **                                                                           **
 * ** No license under any patent, copyright, trade secret or other             **
 * ** intelectual property right is granted to or conferred upon you by         **
 * ** disclosure or delivery of the Materials, either expressly, by             **
 * ** implication, inducement, estoppel or otherwise.  Any license under such   **
 * ** intelectual property rights must be express and approved by Altera in     **
 * ** writing.                                                                  **
 * **                                                                           **
 * ** Application - PTP Bridge Application v1.0                                 **
 * ** Author - Krishna Kumar S R                                                **
 * ******************************************************************************/
#ifndef __PTP_BRIDGE_REGISTER_INTERFACE_H__
#define __PTP_BRIDGE_REGISTER_INTERFACE_H__

#include "ptpbridgeRegisterMap.h"
#define SIZEOF_MAC_ADDRESS 20
void setIngressArbiterScratchReg(ingressArbiter_t *ingressArbiter, uint32 port, uint32 reg);
void setIngressArbiterDMAConfigPriority(ingressArbiter_t *ingressArbiter, uint32 port, uint32 pri);
void setIngressArbiterUserConfigPriority(ingressArbiter_t *ingressArbiter, uint32 port, uint32 pri);

void setEgressRXDemuxScratchReg(egressRXDemux_t *egressRXDemux, uint32 port, uint32 reg);
void setEgressRXDemuxControlReg(egressRXDemux_t *egressRXDemux, uint32 port, uint32 reg);
void setEgressRXDemuxDMA0DropThresholdReg(egressRXDemux_t *egressRXDemux, uint32 port, uint32 reg);
void setEgressRXDemuxDMA1DropThresholdReg(egressRXDemux_t *egressRXDemux, uint32 port, uint32 reg);
void setEgressRXDemuxDMA2DropThresholdReg(egressRXDemux_t *egressRXDemux, uint32 port, uint32 reg);

void setIngressRXWidthAdapterScratchReg(ingressRXWidthAdapter_t *ingressRXWidthAdapter, uint32 port, uint32 reg);
void setIngressRXWidthAdapterControlReg(ingressRXWidthAdapter_t *ingressRXWidthAdapter, uint32 port, uint32 reg);
void setIngressRXWidthAdapterCfgThresholdReg(ingressRXWidthAdapter_t *ingressRXWidthAdapter, uint32 port, uint32 reg);

void setEgressRXWidthAdapterScratchReg(egressRXWidthAdapter_t *egressRXWidthAdapter, uint32 port, uint32 reg);
void setEgressRXWidthAdapterControlReg(egressRXWidthAdapter_t *egressRXWidthAdapter, uint32 port, uint32 reg);
void setEgressRXWidthAdapterCfgDropThresholdReg(egressRXWidthAdapter_t *egressRXWidthAdapter, uint32 port, uint32 reg);

void settcamRegisterScratchReg(tcamRegisterSet_t *tcamRegisterSet, uint32 reg);

int checktcamGeneralControlInitDone(tcamRegisterSet_t *tcamRegisterSet);
void tcamMgmtControlWaitTillBusyDone(tcamRegisterSet_t *tcamRegisterSet);
int tcamMgmtControlOperationResult(tcamRegisterSet_t *tcamRegisterSet);

int tcamMgmtControlSetOpType(tcamRegisterSet_t *tcamRegisterSet, uint32 opType);
int tcamSetEntry(tcamRegisterSet_t *tcamRegisterSet, uint32 entry);
int tcamWarningReadAndReset(tcamRegisterSet_t *tcamRegisterSet, uint32 *warning);
int tcamWarningReadAndReset(tcamRegisterSet_t *tcamRegisterSet, uint32 *warning);
int tcamMonitorReadAndReset(tcamRegisterSet_t *tcamRegisterSet, uint32 *monitor);
int settcamRegisterPTPBridgeKeyDestMacAddress(ptpBridgeKey_t *key, ptpBridgeMask_t *mask, char *mac);
int settcamRegisterPTPBridgeKeySrcMacAddress(ptpBridgeKey_t *key, ptpBridgeMask_t *mask, char *mac);
int settcamRegisterPTPBridgeKeyDestIPAddress(ptpBridgeKey_t *key, ptpBridgeMask_t *mask, char *ipaddr);
int settcamRegisterPTPBridgeKeySrcIPAddress(ptpBridgeKey_t *key, ptpBridgeMask_t *mask, char *ipaddr);
int settcamRegisterPTPBridgeKeyDestL4Port(ptpBridgeKey_t *key, ptpBridgeMask_t *mask, uint16 port);
int settcamRegisterPTPBridgeKeySrcL4Port(ptpBridgeKey_t *key, ptpBridgeMask_t *mask, uint16 port);
int settcamRegisterPTPBridgeKeyVLANB(ptpBridgeKey_t *key, ptpBridgeMask_t *mask, uint16 vlan);
int settcamRegisterPTPBridgeKeyVLANA(ptpBridgeKey_t *key, ptpBridgeMask_t *mask, uint16 vlan);
int settcamRegisterPTPBridgeKeyEthType(ptpBridgeKey_t *key, ptpBridgeMask_t *mask, uint16 ethType);
int settcamRegisterPTPBridgeKeyIPProtocol(ptpBridgeKey_t *key, ptpBridgeMask_t *mask, uint8 ipProtocol);
int settcamRegisterPTPBridgeKeyMessageType(ptpBridgeKey_t *key, ptpBridgeMask_t *mask, uint8 type);
int settcamRegisterPTPBridgeKeyFlagField(ptpBridgeKey_t *key, ptpBridgeMask_t *mask, uint16 flag);

int settcamRegisterPTPBridgeMaskDestMacAddress(ptpBridgeMask_t *mask, char *mac);
int settcamRegisterPTPBridgeMaskSrcMacAddress(ptpBridgeMask_t *mask, char *mac);
int settcamRegisterPTPBridgeMaskDestIPAddress(ptpBridgeMask_t *mask, char *ipaddr);
int settcamRegisterPTPBridgeMaskSrcIPAddress(ptpBridgeMask_t *mask, char *ipaddr);
int settcamRegisterPTPBridgeMaskDestL4Port(ptpBridgeMask_t *mask, uint16 port);
int settcamRegisterPTPBridgeMaskSrcL4Port(ptpBridgeMask_t *mask, uint16 port);
int settcamRegisterPTPBridgeMaskVLANB(ptpBridgeMask_t *mask, uint16 vlan);
int settcamRegisterPTPBridgeMaskVLANA(ptpBridgeMask_t *mask, uint16 vlan);
int settcamRegisterPTPBridgeMaskEthType(ptpBridgeMask_t *mask, uint16 ethType);
int settcamRegisterPTPBridgeMaskIPProtocol(ptpBridgeMask_t *mask, uint8 ipProtocol);
int settcamRegisterPTPBridgeMaskMessageType(ptpBridgeMask_t *mask, uint8 type);
int settcamRegisterPTPBridgeMaskFlagField(ptpBridgeMask_t *mask, uint16 flag);

int settcamRegisterResult(tcamRegisterSet_t *tcamRegisterSet, uint32 result);
//int settcamRegisterMask(tcamRegisterSet_t *tcamRegisterSet, uint64 mask);
int settcamRegisterMatch(tcamRegisterSet_t *tcamRegisterSet, uint32 match);

void dumptcamRegisterPTPBridgeArray(uint32 *array, int num, const char *header);
void dumptcamRegisterSetMultiple(tcamRegisterSet_t *tcamRegisterSet, int port);
void dumptcamRegisterPTPBridgeKeyMultiple(ptpBridgeKey_t *keys);
void *memcpy32(uint32_t *dest, const uint32_t *src, size_t count);
void dumpPTPBridgeDetails(ptpBridge_t* ptpBridgei, int port);
void print_mac_address(const mac_address *macAddr, const char *header);
#ifdef DEBUG_REG_SUPPORT
int ptpBridgeFlushAllTxCounters(ptpBridgeTxDebugReg_t *tx);
int ptpBridgeFlushAllRxCounters(ptpBridgeRxDebugReg_t *rx);
#endif

int readMacAddressPerIFace (const char *iface, char *mac);
int isEthernetPortValid(char *eth);
int validate_mac(mac_address *macAddr, const char *arg);

void bigEndianToLittleEndian_32(uint32_t *x);
void littleEndianToBigEndian_32(uint32_t *x);
void bigEndianToLittleEndian_16(uint16_t *x);
void littleEndianToBigEndian_16(uint16_t *x);
void bigEndianToLittleEndian_in6Addr(struct in6_addr *addr);
void littleEndianToBigEndian_in6Addr(struct in6_addr *addr);

#endif //__PTP_BRIDGE_REGISTER_INTERFACE_H__
